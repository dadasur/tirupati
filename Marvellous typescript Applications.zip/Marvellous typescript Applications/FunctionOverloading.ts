// Function Overloading

function add(no1:number, no2:number):number
{
    var iret:number;
    iret = no1+no2;
    return iret;
}